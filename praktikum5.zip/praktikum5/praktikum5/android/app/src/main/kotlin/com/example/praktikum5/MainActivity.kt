package com.example.praktikum5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
