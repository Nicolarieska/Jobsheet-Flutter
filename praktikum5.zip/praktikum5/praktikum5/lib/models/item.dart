class Item {
  String name;
  int price;
  String code;

  Item({this.name, this.price, this.code});
}
