package com.example.flutter_application_belanja

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
