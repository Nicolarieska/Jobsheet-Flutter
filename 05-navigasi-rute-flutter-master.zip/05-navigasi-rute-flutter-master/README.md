# flutter_application_belanja

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
![Screenshot (56)](https://user-images.githubusercontent.com/89899666/159160000-a0a22abd-7a2c-4342-b386-9f5ad81dffbb.png)
![Screenshot (57)](https://user-images.githubusercontent.com/89899666/159160002-93e3e859-e4cb-4ff9-a810-975a7558c7bd.png)
