class Item {
  String name;
  int price;
  String code;

  Item({required this.name, required this.price, required this.code});
}
