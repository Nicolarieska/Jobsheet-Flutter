# sqlite_flutter

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

![WhatsApp Image 2022-04-04 at 22 41 55](https://user-images.githubusercontent.com/89899666/161581178-33b1dcdd-8d57-48c5-90f8-1094acb8ed27.jpeg)
![WhatsApp Image 2022-04-04 at 22 41 54 (2)](https://user-images.githubusercontent.com/89899666/161581184-64636254-a840-40e0-ad93-eccd8f3b3167.jpeg)
![WhatsApp Image 2022-04-04 at 22 41 54 (1)](https://user-images.githubusercontent.com/89899666/161581187-31d1da18-cc93-4e16-aa68-057565c31b4d.jpeg)
![WhatsApp Image 2022-04-04 at 22 41 54](https://user-images.githubusercontent.com/89899666/161581190-ed99d5b0-0f2f-4ddd-8c87-472f29549b9d.jpeg)
